const budget_button = document.getElementById("budget")
const budget_corp_button = document.getElementById("budget-corp")
const listBudget_button = document.getElementById("list-budgets")
const TOKEN_RD = "649dcc1c48f91a001f09be68";

console.log(chrome.tabs)
listBudget_button.addEventListener("click", async (e) => {
    e.preventDefault()
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true})

    if(!tab.url.includes("https://crm.rdstation.com/app#/deals/")) {
        return
    }

    const deal_id = tab.url.split("deals/")[1]
    openBudgetsList(deal_id)
})

budget_button.addEventListener("click", async (e)=> {
    e.preventDefault()
    const  { deal_id, checkIn, checkOut, adt, chd, pet } = await getFieldsRD();
    openBudgetPage(
        deal_id, organizeDate(checkIn), organizeDate(checkOut), adt, chd, pet
    );
})

budget_corp_button.addEventListener("click", async e => {
    e.preventDefault();
    const  { deal_id, checkIn, checkOut } = await getFieldsRD();
    openBudgetCorpPage(
        deal_id, organizeDate(checkIn), organizeDate(checkOut)
    );
})

async function getFieldsRD() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true})
    if(!tab.url.includes("https://crm.rdstation.com/app#/deals/")) {
        return
    }

    const deal_id = tab.url.split("deals/")[1]
    console.log(" [ INFO ] get deals id: ", deal_id)
    const noJson = await getDealInformation(deal_id)
    const rdResponse = JSON.parse(noJson)
    const checkIn = rdResponse?.deal_custom_fields?.filter(customField =>
        customField.custom_field_id === "64ff4e1f2ab269001b8bb10f")[0]?.value ?? ""
    const checkOut = rdResponse?.deal_custom_fields?.filter(customField =>
        customField.custom_field_id === "64ff4e32966cc10022693bc2")[0]?.value ?? ""
    const adt = rdResponse?.deal_custom_fields?.filter(customField =>
        customField.custom_field_id === "64b7e57ec69b74000c0dfffc")[0]?.value ?? ""
    const chd = rdResponse?.deal_custom_fields?.filter(customField =>
        customField.custom_field_id === "64b7ed74bfabcc002b264818")[0]?.value ?? ""
    const pet = rdResponse?.deal_custom_fields?.filter(customField =>
        customField.custom_field_id === "64b7edb9f217510019a64bc5")[0]?.value ?? ""
    console.log(rdResponse)

    return { deal_id, checkIn, checkOut, adt, chd, pet }
}


async function getDealInformation(deal_id) {
    const url = `https://crm.rdstation.com/api/v1/deals/${deal_id}/?token=${TOKEN_RD}`
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", url, false)
    xhttp.send();
    return xhttp.responseText
}

const openBudgetPage = (deal_id, check_in, check_out, adt, chd, pet) => {
    const url =
        `http://192.168.10.87:83/?check-in=${check_in}&check-out=${check_out}&adt=${adt}&chd=${chd}&client_id=${deal_id}&pet=${pet}`
    // Configurações da janela popup
    const width = 1000; // Largura da janela em pixels
    const height = 650; // Altura da janela em pixels
    const left = (window.innerWidth - width) / 2; // Centraliza a janela horizontalmente
    const top = (window.innerHeight - height) / 2; // Centraliza a janela verticalmente
    const features = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`;

    // Abre a janela popup
    window.open(url, '_blank', features);
}

const openBudgetCorpPage = (deal_id, check_in, check_out) => {
    const url =
        `http://192.168.10.87:83/corporate?check-in=${check_in}&check-out=${check_out}&client_id=${deal_id}`
    // Configurações da janela popup
    const width = 1000; // Largura da janela em pixels
    const height = 650; // Altura da janela em pixels
    const left = (window.innerWidth - width) / 2; // Centraliza a janela horizontalmente
    const top = (window.innerHeight - height) / 2; // Centraliza a janela verticalmente
    const features = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`;

    // Abre a janela popup
    window.open(url, '_blank', features);
}

const openBudgetsList = (deal_id) => {
    console.log("budget-list")
    const url =
        `http://192.168.10.87:83/budgets?find=${deal_id}`
    // Configurações da janela popup
    const width = 1000; // Largura da janela em pixels
    const height = 650; // Altura da janela em pixels
    const left = (window.innerWidth - width) / 2; // Centraliza a janela horizontalmente
    const top = (window.innerHeight - height) / 2; // Centraliza a janela verticalmente
    const features = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`;

    // Abre a janela popup
    window.open(url, '_blank', features);
}

function organizeDate(date) {
    if(date.split("/").length === 3 ) {
        const [day, month, year] = date.split("/")
        if(day && month && year) return `${year}/${month}/${day}`
    } else {
        const [year, month, day] = date.split("-")
        if(day && month && year) return `${year}/${month}/${day}`
    }

    return ""
}


